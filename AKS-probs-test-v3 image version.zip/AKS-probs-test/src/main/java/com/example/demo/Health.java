package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Health {
	
	@GetMapping("/health-check")
	public static String Health() {
		return "Health Check page. health-check Ststus 'OK'. additional readiness prob.";
	}

}
