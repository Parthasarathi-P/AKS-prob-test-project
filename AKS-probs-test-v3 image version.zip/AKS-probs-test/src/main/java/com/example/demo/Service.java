package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Service {
	
	@GetMapping("/Service-Health")
	public static String Service() {
		return "Service Health page. Service-Health Ststus 'OK' \n additional liveness prob.";
	}
}
